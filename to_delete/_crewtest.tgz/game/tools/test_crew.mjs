// Checks clan money, crew cap and hire prices in the sim: node game/tools/test_crew.mjs
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import { createGame } from '../src/sim/game.js';

const data = f => JSON.parse(readFileSync(new URL(`../${f}`, import.meta.url)));
const units = data('data/units.json');
const game = createGame({
  district: data('data/waterfront.json'), catalog: data('data/art.json'), cutouts: data('art/cutouts.json'),
  interiors: data('data/interiors.json'), parts: data('data/interior_parts.json'), recipes: data('data/room_recipes.json'), units,
});
const { state, clans } = game;
const R = units.rules;

const player = clans.addClan('player');
const bot = clans.addClan('kuroda', { name: 'Kuroda clan', bot: true });
assert.equal(player.ryo, R.startRyo);
assert.equal(bot.bot, true);

// The waterfront has a teahouse, warehouse and den, nobody owns them at the start
const kinds = Object.values(state.businesses).map(b => b.kind).sort();
assert.deepEqual(kinds, ['gambling_den', 'teahouse', 'warehouse']);
assert.equal(clans.crewCap('player'), R.baseCap);

// Holding businesses raises the cap, for players and bots alike
const tea = Object.values(state.businesses).find(b => b.kind === 'teahouse');
const den = Object.values(state.businesses).find(b => b.kind === 'gambling_den');
clans.setOwner(tea.id, 'player');
clans.setOwner(den.id, 'kuroda');
assert.equal(clans.crewCap('player'), R.baseCap + R.capPerBusiness.teahouse);
assert.equal(clans.crewCap('kuroda'), R.baseCap + R.capPerBusiness.gambling_den);

// The hero is not crew; each crew member makes the next hire dearer
game.spawn('hero', 'ronin', 0, 0, { owner: 'player' });
assert.equal(clans.crewOf('player').length, 0);
assert.equal(clans.hirePrice('player', 'thug'), 60);
game.spawn('thug', 'thug', 1, 0, { owner: 'player' });
game.spawn('thug', 'thug', 2, 0, { owner: 'player' });
assert.equal(clans.crewOf('player').length, 2);
assert.equal(clans.hirePrice('player', 'thug'), Math.round(60 * (1 + 2 * R.priceStepPerCrew)));
assert.equal(clans.hirePrice('kuroda', 'thug'), 60);

// Types waiting on later systems cannot be hired; unknown types neither
assert.equal(clans.hirePrice('player', 'rifleman'), null);
assert.equal(clans.hirePrice('player', 'samurai'), null);

// --- Hiring (phase 2) ---
// A fresh game: hero walks into the teahouse and hires through commands, like a player would
function fresh() {
  const g = createGame({
    district: data('data/waterfront.json'), catalog: data('data/art.json'), cutouts: data('art/cutouts.json'),
    interiors: data('data/interiors.json'), parts: data('data/interior_parts.json'), recipes: data('data/room_recipes.json'), units,
  });
  return g;
}
const g = fresh();
const teaId = Object.values(g.state.businesses).find(b => b.kind === 'teahouse').id;
const teaB = g.state.businesses[teaId];
const ticks = s => Math.ceil(s * 20) + 1;
const run = (n, cmds = []) => { g.step(cmds); for (let i = 1; i < n; i++) g.step(); };
const crew = id => Object.values(g.state.entities).filter(e => e.owner === id && e.type !== 'hero');

for (const [clanId, bot] of [['player', false], ['kuroda', true]]) {
  g.clans.addClan(clanId, { bot });
  const hero = g.spawn('hero', 'ronin', teaB.door[0], teaB.door[1], { owner: clanId });
  const clan = g.state.clans[clanId];

  // Outside the teahouse: refused, nothing paid
  run(1, [{ id: hero, type: 'hire', business: teaId, unit: 'thug' }]);
  assert.equal(clan.ryo, R.startRyo);
  assert.match(clan.notice.text, /inside a teahouse/);

  // Walk in through the door, then hire a thug
  run(1, [{ id: hero, type: 'use' }]);
  assert.equal(g.state.entities[hero].place, teaB.room);
  run(1, [{ id: hero, type: 'hire', business: teaId, unit: 'thug' }]);
  assert.equal(clan.ryo, R.startRyo - 60);
  assert.equal(clan.queue.length, 1);
  assert.equal(crew(clanId).length, 0);

  // Arrives at the teahouse door when the timer ends, owned by the clan
  run(ticks(units.types.thug.hireSeconds));
  assert.equal(clan.queue.length, 0);
  const t = crew(clanId);
  assert.equal(t.length, 1);
  assert.equal(t[0].type, 'thug');
  assert.equal(t[0].hp, units.types.thug.hp);
  assert.equal(t[0].place, 'street');

  // Locked types refused; cap counts waiting hires; money runs out
  run(1, [{ id: hero, type: 'hire', business: teaId, unit: 'rifleman' }]);
  assert.match(clan.notice.text, /Nobody here/);
  run(1, [{ id: hero, type: 'hire', business: teaId, unit: 'brute' }]);   // 100 * 1.15 = 115, ryo 240 -> 125
  assert.equal(clan.ryo, 125);
  run(1, [{ id: hero, type: 'hire', business: teaId, unit: 'swordsman' }]); // 120 * 1.3 = 156 > 125
  assert.match(clan.notice.text, /Not enough ryo/);
  clan.ryo = 1000;
  run(1, [{ id: hero, type: 'hire', business: teaId, unit: 'thug' }]);     // now 3 of 3 (1 here + 2 waiting)
  run(1, [{ id: hero, type: 'hire', business: teaId, unit: 'thug' }]);
  assert.match(clan.notice.text, /Crew is full/);
  run(ticks(units.types.brute.hireSeconds + units.types.thug.hireSeconds));
  assert.equal(crew(clanId).length, 3);
  assert.equal(clan.queue.length, 0);

  // Crew can move (their stats come from units.json)
  const c = crew(clanId)[0], x0 = c.x;
  run(10, [{ id: c.id, type: 'move', right: 1, down: 0, walk: true }]);
  assert.notEqual(c.x, x0);
  run(1, [{ id: c.id, type: 'move', right: 0, down: 0 }]);
}

// Crew cannot hire, and a hero cannot spend another clan's money
const someThug = crew('player')[0];
const before = g.state.clans.player.ryo;
run(1, [{ id: someThug.id, type: 'hire', business: teaId, unit: 'thug' }]);
assert.equal(g.state.clans.player.ryo, before);
assert.deepEqual(JSON.parse(JSON.stringify(g.state)), g.state);

// The whole state stays plain data (it has to sync to other players later)
assert.deepEqual(JSON.parse(JSON.stringify(state)), state);
console.log('crew tests passed');
